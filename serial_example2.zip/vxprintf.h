// printf-like formatted output - header file

#ifndef VXPRINTF_H
#define VXPRINTF_H

#include <stdarg.h>

void vxprintf(int txchar(unsigned char), char *fmt, va_list args);

#endif  // VXPRINTF_H
