// interrupt-driven serial debug output routines (DBGU)

#include <stdarg.h>
#include "common.h"
#include "device.h"
#include "board.h"
#include "vxprintf.h"
#include "trace.h"

#define TXBUF_SIZE 256                          // size of transmit buffer

static unsigned char txbuf[TXBUF_SIZE];         // transmit buffer (FIFO queue)
static unsigned char *txfirst, *txlast;         // pointers to first and last bytes in queues
static int volatile txlen;                      // number of bytes in queues

void INTERRUPT trace_txint(void) {
    unsigned char c;

    if (txlen<=0) {                             // last byte just sent?
        AT91F_US_DisableIt(                     // yep, disable tx int
            (AT91PS_USART)AT91C_BASE_DBGU, AT91C_US_TXRDY);
        return;                                 // and don't do anything more
    }
    c = *txfirst++;                             // remove first byte from queue
    if (txfirst>=txbuf+TXBUF_SIZE)              // wrap around if we've hit the end
        txfirst = txbuf;
    txlen--;
    
    AT91F_US_PutChar(                           // transmit it (to tx holding register)
        (AT91PS_USART)AT91C_BASE_DBGU, c);

    END_INTERRUPT();                            // acknowledge interrupt
}

// initialise debug routine
void trace_init(void) {
    // init buffer variables
    txfirst = txlast = txbuf;
    txlen = 0;

    // Clock DBGU and configure its pins
    AT91F_DBGU_CfgPMC();
    AT91F_DBGU_CfgPIO();

    AT91F_US_Configure((AT91PS_USART) AT91C_BASE_DBGU,
                       AT91C_MASTER_CLOCK,
                       AT91C_US_ASYNC_MODE,
                       DBGU_BAUDRATE,
                       0);

    // Configure and enable debug transmit interrupt (via system interrupt)
    AT91F_AIC_ConfigureIt(AT91C_BASE_AIC,
                          AT91C_ID_SYS,
                          AT91C_AIC_PRIOR_LOWEST,
                          0, //AT91C_AIC_SRCTYPE_INT_HIGH_LEVEL,
                          trace_txint);
    AT91F_AIC_EnableIt(AT91C_BASE_AIC, AT91C_ID_SYS);

    // Enable Transmitter & Receiver
    AT91F_US_EnableTx((AT91PS_USART) AT91C_BASE_DBGU);
    AT91F_US_EnableRx((AT91PS_USART) AT91C_BASE_DBGU);
}

// transmit byte (and return it, or -1 if queue full and byte not sent)
int trace_tx(unsigned char c) {
    if (txlen>=TXBUF_SIZE) return -1;           // transmit queue full, discard byte
    AT91F_US_DisableIt(                         // disable interrupts (so int doesn't mess with queue too)
        (AT91PS_USART)AT91C_BASE_DBGU, AT91C_US_TXRDY);
    *txlast++ = c;                              // add byte to end of transmit queue
    if (txlast>=txbuf+TXBUF_SIZE)               // wrap around if we've hit the end
        txlast = txbuf;
    txlen++;
    AT91F_US_EnableIt(                          // re-enable transmit ready interrupt
        (AT91PS_USART)AT91C_BASE_DBGU, AT91C_US_TXRDY);
    return c;
}

// our cut-down version of printf(), but send to debug port
void trace(char *fmt, ...) {
    va_list args;

    va_start(args, fmt);
    vxprintf(trace_tx, fmt, args);
    va_end(args);
}
